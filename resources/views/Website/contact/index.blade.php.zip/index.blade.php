@extends('Website.layouts.app')
<!-- @php  $set=setting();  @endphp -->

@section('style')
<style>
    :root {
        --primary-color: #000;
        --secondary-color: #fff;
        --accent-color: #4CAF50;
        --text-color-light: #fff;
        --text-color-dark: #333;
        --grey-text: #666;
        --form-bg-dark: #1a1a1a;
    }
    .char-animate span {
    opacity: 0;
    transform: translateY(14px);
    display: inline-block;
    transition: opacity 0.45s ease, transform 0.45s ease;
}

.char-animate.animate span {
    opacity: 1;
    transform: translateY(18px);
    transition: opacity 0.5s cubic-bezier(.25,.46,.45,.94),
                transform 0.5s cubic-bezier(.25,.46,.45,.94);
}
</style>
@endsection
@section('content')
<section class="row" style="margin:0;">
    <div class="col-md-12 ">
        <img src="{{ url('public/banners/simone-hutsch-xlGKy9UokjQ-unsplash-1-1.jpg') }}" style="object-fit: cover;" height="500px" width="100%" alt="">
        <div class="social-icon-wrapperss ">
            <a href="https://www.instagram.com/bhardwaj_architects/?igshid=OGQ5ZDc2ODk2ZA%3D%3D/" target="_blank" title="Instagram">
                <svg aria-hidden="true" viewBox="0 0 448 512">
                    <path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"></path>
                </svg>
            </a>
            <a href="https://www.youtube.com/@bhardwajarchitects75" target="_blank" title="Youtube">
                <svg aria-hidden="true" viewBox="0 0 576 512">
                    <path d="M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z"></path>
                </svg>
            </a>
            <a href="https://www.facebook.com/Bhardwajarchitects?mibextid=LQQJ4d" target="_blank" title="Facebook" class="mx-3 text-white">
                <svg aria-hidden="true" viewBox="0 0 320 512" width="30" height="30" fill="white">
                    <path d="M279.14 288l14.22-92.66h-88.91V127.75c0-25.35 12.42-50.06 52.24-50.06H293V6.26S259.56 0 225.36 0c-73.1 0-121.15 44.38-121.15 124.72v70.62H22.89V288h81.32v224h100.2V288z" />
                </svg>
            </a>

            <a href="https://wa.me/919876543210" target="_blank" title="WhatsApp" class="mx-3 text-white">
                <svg aria-hidden="true" viewBox="0 0 448 512" width="30" height="30" fill="white">
                    <path d="M380.9 97.1C339-12.2 219.2-30.3 135.7 22.8c-82.1 51.9-109.8 160-62 244l-26.6 97.6 100.2-26.3c76 40.3 171.6 22.8 229.2-42.1 63.1-70.6 73.7-173.5 27.7-251zM224.1 338.3c-26.4 0-52.3-6.9-74.9-19.9l-5.3-3.2-44.3 11.6 11.8-43.4-3.4-5.4c-13.5-21.5-20.7-46.2-20.7-71.7 0-74.7 60.8-135.5 135.5-135.5 36.2 0 70.3 14.1 95.9 39.7s39.7 59.7 39.7 95.9c-.1 74.8-60.9 135.6-135.3 135.6z" />
                </svg>
            </a>

        </div>

    </div>
</section>
<section class="contact-section">
    <div class="contact-container">

        <div class="contact-column contact-info-column">
            <div class="info-content-wrap">
                <h1 class="main-heading char-animate"><span class="animated-texts">Let's Talk</span></h1>
                <h2 class="sub-heading">Got a project on your mind? Let's discuss about the details.</h2>
                <a href="{{route('website.appointment')}}" class="cta-button outlined-icon-right" style="background-color:#000;"><span class="button-text">Request An Appointment</span>
                    <span class="button-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="7px" height="7px" viewBox="1.25 1.25 7 7">
                            <polygon fill="#ffffff" points="1.25,1.25 1.25,2.25 6.543,2.25 1.25,7.543 1.958,8.25 7.25,2.957 7.25,8.25 8.25,8.25 8.25,1.25 8.25,1.25 "></polygon>
                        </svg>
                    </span>
                </a>
                <div class="spacer"></div>
                <h3 class="call-heading">Call Us</h3>
                <h2 class="phone-number">
                    @php
                    $contacts = array_filter([
                    $set['contact'] ?? null,
                    $set['contact1'] ?? null,
                    $set['contact2'] ?? null
                    ]);
                    @endphp

                    @foreach($contacts as $contact)
                    <a href="tel:{{ $contact }}" style="color:#000000;">
                         {{ $contact }}
                    </a>@if(!$loop->last), @endif
                    @endforeach

                </h2>
                <h3 class="call-heading">Find Us</h3>
                <h2 class="location "><a href="https://goo.gl/maps/g4pU6vd3KWSCQHKr5" style="color : #000000;">{{ $set['address'] }}</a></h2>

                <div class="social-icons">

                </div>
            </div>
        </div>

        <div class="contact-column contact-form-column">
            <div class="form-wrapper">
                <h1 class="form-title">Contact Us</h1>
                <div class="appointment-form-grid text-center " id="response-message">
                    <div class="response-message" class="row"></div>
                </div>
                <p class="form-description">Fill out the form below and we will contact you as soon as possible</p>
                <!-- <div id="response-message" style=" padding:15px; margin-bottom: 20px; border-radius:5px; text-align:center; font-weight: bold; transition: all 0.5s;"></div> -->

                <form id="contactForm" class="contact-form" method="POST" action="">

                    <input type="hidden" name="form_type" value="contact">
                    <div class="form-fields-wrapper">
                        <div class="form-field half-width">
                            <input type="text" name="name" placeholder="Your Name" class="pl-2" required>
                        </div>
                        <div class="form-field half-width">
                            <input type="email" name="email" placeholder="Your Email" class="pl-2" required>
                        </div>
                        <div class="form-field half-width">
                            <input type="tel" name="phone" placeholder="Phone Number" class="pl-2" required>
                        </div>
                        <div class="form-field half-width">
                            <input type="text" name="area" placeholder="Area" class="pl-2" required>
                        </div>
                        <div class="form-field full-width">
                            <textarea name="message" rows="4" placeholder="Message" class="pl-2"></textarea>
                        </div>
                        <div class="form-field full-width submit-field">
                            <button type="submit" class="submit-button">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<section class="info-section pt-0">
    <div class="container page-wrappers  pl-2 pr-2">
        <div class="animated-title-wrapper">
            <h1 class="section-title  show  headerofmap char-animate">DESIGNING ACROSS BORDERS</h1>
        </div>
        <div class="content-area">
            <div class="stats-column">
                <div class="map-counter">
                    <div class="map-counter-title ">LOCAL PROJECTS</div>
                    <div class="map-counter-number-wrapper milestone-counter">
                        <span class="map-counter-number" data-num="12">12</span>
                        <span class="map-counter-number-suffix">K</span>
                    </div>
                </div>



                <div class="map-counter">
                    <div class="map-counter-title ">INTERNATIONAL PROJECTS</div>
                    <div class="map-counter-number-wrapper milestone-counter">
                        <span class="map-counter-number" data-num="75">75</span>
                        <span class="map-counter-number-suffix"></span>
                    </div>
                </div>

                <div class="map-counter">
                    <div class="map-counter-title ">CONSTRUCTION PROJECTS</div>
                    <div class="map-counter-number-wrapper milestone-counter">
                        <span class="map-counter-number" data-num="100">1,623</span>
                        <span class="map-counter-number-suffix"></span>
                    </div>
                </div>
            </div>

            <div id="chartdiv" class="map-column"></div>
        </div>

    </div>
</section>
<section class="cta-section " style="background-image: url('assetss/images/services/imgi_13_16.jpg');">
    <div class="cta-overlay"></div>
    <div class="cta-container">

        <div class="cta-heading-group animated-element">
            <h1 class="cta-main-heading">
                Have a project in mind?
            </h1>
        </div>

        <div class="cta-heading-group animated-element delay-200">
            <h2 class="cta-sub-heading">
                Do not hesitate to say
                <span class="typeout-text">Hello</span>
                <span class="typed-cursor">|</span>
            </h2>
        </div>

        <div class="cta-button-wrapper animated-element delay-400">
            <a href="{{route('website.appointment')}}" class="cta-button">
                <span class="button-text">Request An Appointment</span>
                <span class="button-icon-box">
                    <svg viewBox="1.25 1.25 7 7" aria-hidden="true" width="7px" height="7px">
                        <polygon points="1.25,1.25 1.25,2.25 6.543,2.25 1.25,7.543 1.958,8.25 7.25,2.957 7.25,8.25 8.25,8.25 8.25,1.25 8.25,1.25 "></polygon>
                    </svg>
                </span>
            </a>
        </div>

    </div>
</section>
@endsection
@section('script')
@endsection